export const carData = {
    Tata: ["Nexon", "Harrier", "Altroz"],
    Maruti: ["Swift", "Ertiga", "Frongz"],
    Hyundai: ["Creta", "Venue", "Amaze"],
    Renault: ["Kwid", "Triber"],
    Toyota: ["Innova Crysta", "Innova HyCross", "Fortuner"],
  };
  