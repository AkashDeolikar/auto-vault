// import React from "react";

// const ModelSelector = ({ models, selectedModel, onChange }) => (
//   <select value={selectedModel} onChange={(e) => onChange(e.target.value)}>
//     <option value="">Select Model</option>
//     {models.map((model) => (
//       <option key={model} value={model}>{model}</option>
//     ))}
//   </select>
// );

// export default ModelSelector;