// import React from "react";

// const BrandSelector = ({ brands, selectedBrand, onChange }) => (
//   <select value={selectedBrand} onChange={(e) => onChange(e.target.value)}>
//     <option value="">Select Brand</option>
//     {brands.map((brand) => (
//       <option key={brand} value={brand}>{brand}</option>
//     ))}
//   </select>
// );

// export default BrandSelector;
